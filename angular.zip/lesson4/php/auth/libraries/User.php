<?php

/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/22/2016
 * Time: 7:29 PM
 */
class User
{
    public function login(){}
    public function register(){}
}