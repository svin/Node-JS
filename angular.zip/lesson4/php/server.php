<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/18/2016
 * Time: 5:37 AM
 */

var_dump($_SERVER);