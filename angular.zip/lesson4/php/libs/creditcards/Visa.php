<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/18/2016
 * Time: 3:52 AM
 */

namespace creditcards;


class Visa extends CreditCardAbstract 
{
    public function createTransaction()
    {
        // TODO: Implement createTransaction() method.
    }
    public function getResponse()
    {
        // TODO: Implement getResponse() method.
    }
    public function setCC()
    {
        // TODO: Implement setCC() method.
    }

}