<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/18/2016
 * Time: 3:52 AM
 */

namespace creditcards;


class Isracard extends CreditCardAbstract implements CreditCardsInterface,\Iterator
{
    public function createTransaction()
    {
        // TODO: Implement createTransaction() method.
    }
    public function getResponse()
    {
        // TODO: Implement getResponse() method.
    }
    public function setCC()
    {
        // TODO: Implement setCC() method.
    }
    public function doA()
    {
        // TODO: Implement doA() method.
    }
    public function doB()
    {
        // TODO: Implement doB() method.
    }
    function current()
    {
        // TODO: Implement current() method.
    }
    function key()
    {
        // TODO: Implement key() method.
    }
    function next()
    {
        // TODO: Implement next() method.
    }
    function rewind()
    {
        // TODO: Implement rewind() method.
    }
    function valid()
    {
        // TODO: Implement valid() method.
    }
}