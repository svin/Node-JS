<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/22/2016
 * Time: 7:09 PM
*/

// 1. check against the DB for the credentials authentication

// 2. if result returned:
//      a. store the data into the $_SESSION
//            a.1 auth: true
//            a.2 userDbObject
//      b. redirect the user

// 3. else:
//     return false