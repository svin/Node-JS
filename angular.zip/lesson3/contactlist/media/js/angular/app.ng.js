var ContactListApp = angular.module('ContactListApp',[]);
// configurations