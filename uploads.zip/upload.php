<?php
var_dump($_FILES);
//current file location
$src= $_FILES['pic']['tmp_name'];
//file dest
$dst='./uploads/'.$_FILES['pic']['name'];
if(!is_writable('./uploads/')){
  die('upload is not exists or not wrieable');
}
move_uploaded_file($src,$dst);
