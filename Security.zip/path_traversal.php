<?php
$imageName = str_replace(['..','/'],['',''],$_GET['img']);
$userIsBuyer= true;
if($userIsBuyer){	
	$imgPath="../../secureImages/$imageName";
	if(file_exists($imgPath)){
		header("Content-Type: image/jpg");
		readfile($imgPath);
	}
	else{
		die("404 file not exists");
	}
	
}