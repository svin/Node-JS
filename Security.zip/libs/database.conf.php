<?php
define("DB_PASS",1234);