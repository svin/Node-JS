<?php
header('Content-Type: text/html; charset=utf-8');
$email= mysql_real_escape_string($_GET['email']);
$page = (int) $_GET['page'];
$email= str_replace("'","\'",$email);

$sql = "SELECT * FROM users
		WHERE `email`='{$_GET['email']}'
		LIMIT 1";
		?>
		
<?=$email;?><br/><br/>
<?=$sql;?>