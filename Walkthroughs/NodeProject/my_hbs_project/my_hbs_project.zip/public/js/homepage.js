(function(){
    document.getElementById('akuz').addEventListener('click', (event) => {
        window.location.href="/users"
    })
})()